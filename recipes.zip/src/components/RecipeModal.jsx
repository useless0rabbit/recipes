// RecipeModal.jsx
import React from 'react';
import './RecipeModal.css';
import ModalHeader from './ModalHeader';

const RecipeModal = ({ recipe, onClose }) => {
  const totalCookTime = recipe.prepTimeMinutes + recipe.cookTimeMinutes;

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <ModalHeader onClose={onClose} />
        <div className="modal-body">
          <h3>{recipe.name}</h3>
          <img src={recipe.image || "https://via.placeholder.com/150"} alt={recipe.name} className="modal-image" />
          <p><strong>Калорийность:</strong> {recipe.caloriesPerServing} ккал</p>
          <p><strong>Количество порций:</strong> {recipe.servings}</p>
          <p><strong>Время приготовления:</strong> {totalCookTime} минут</p>
          <p><strong>Сложность:</strong> {recipe.difficulty}</p>
          <p><strong>Кухня:</strong> {recipe.cuisine}</p>
          <p><strong>Тип блюда:</strong> {recipe.mealType?.join(', ')}</p>
          <p><strong>Теги:</strong> {recipe.tags?.join(', ')}</p>

          <h4>Ингредиенты</h4>
          <ul>
            {recipe.ingredients?.map((ingredient, index) => (
              <li key={index}>{ingredient}</li>
            ))}
          </ul>

          <h4>Инструкции</h4>
          <ol>
            {recipe.instructions?.map((instruction, index) => (
              <li key={index}>{instruction}</li>
            ))}
          </ol>
        </div>
      </div>
    </div>
  );
};

export default RecipeModal;
