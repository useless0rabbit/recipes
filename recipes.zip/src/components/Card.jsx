// Card.jsx
import React from 'react';
import './Card.css';

const Card = ({ recipe, openModal }) => {
  const totalCookTime = recipe.prepTimeMinutes + recipe.cookTimeMinutes;

  return (
    <div className="card" onClick={openModal}>
      <img src={recipe.image || "https://via.placeholder.com/150"} alt={recipe.name} className="card-image" />
      <h3>{recipe.name || 'Название отсутствует'}</h3>
      <p><strong>Время приготовления:</strong> {totalCookTime} минут</p>
      <p><strong>Сложность:</strong> {recipe.difficulty || 'Не указано'}</p>
      <p><strong>Кухня:</strong> {recipe.cuisine || 'Не указано'}</p>
      <p><strong>Тип блюда:</strong> {recipe.mealType?.join(', ') || 'Не указано'}</p>
    </div>
  );
};

export default Card;
