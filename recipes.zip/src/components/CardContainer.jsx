// CardContainer.jsx
import React, { useState } from 'react';
import Card from './Card';
import './CardContainer.css';

const CardContainer = ({ recipes, openModal }) => {
  const [currentPage, setCurrentPage] = useState(1);
  const cardsPerPage = 6;

  // Логика пагинации
  const indexOfLastCard = currentPage * cardsPerPage;
  const indexOfFirstCard = indexOfLastCard - cardsPerPage;
  const currentCards = recipes.slice(indexOfFirstCard, indexOfLastCard);
  const totalPages = Math.ceil(recipes.length / cardsPerPage);

  const handlePageChange = (page) => setCurrentPage(page);

  return (
    <div className="card-container">
      <div className="card-wrapper">
        {currentCards.map((recipe) => (
          <Card
          key={recipe.id}
          recipe={recipe}
          openModal={() => openModal(recipe)}
        />
        ))}
      </div>
      {/* Пагинация */}
      <div className="pagination">
        {[...Array(totalPages).keys()].map((num) => (
          <button
            key={num + 1}
            onClick={() => handlePageChange(num + 1)}
            className={currentPage === num + 1 ? "active" : ""}
          >
            {num + 1}
          </button>
        ))}
      </div>
    </div>
  );
};

export default CardContainer;
