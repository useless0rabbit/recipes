// FilterSidebar.jsx
import React from 'react';
import './FilterSidebar.css';

const FilterSidebar = ({ filters, applyFilters, cuisines, mealTypes }) => {
  const handleCuisineChange = (e) => {
    applyFilters({ ...filters, cuisine: e.target.value });
  };

  const handleMealTypeChange = (e) => {
    applyFilters({ ...filters, mealType: e.target.value });
  };

  const handleDifficultyChange = (difficulty) => {
    applyFilters({ ...filters, difficulty });
  };

  return (
    <div className="filter-sidebar">
      <label>
        Кухня:
        <select value={filters.cuisine} onChange={handleCuisineChange}>
          <option value="">Все</option>
          {cuisines.map((cuisine) => (
            <option key={cuisine} value={cuisine}>{cuisine}</option>
          ))}
        </select>
      </label>
      
      <label>
        Тип блюда:
        <select value={filters.mealType} onChange={handleMealTypeChange}>
          <option value="">Все</option>
          {mealTypes.map((mealType) => (
            <option key={mealType} value={mealType}>{mealType}</option>
          ))}
        </select>
      </label>
      
      <label>Сложность:</label>
      <div className="difficulty-buttons">
        <button onClick={() => handleDifficultyChange('')} className={filters.difficulty === '' ? 'active' : ''}>Все</button>
        <button onClick={() => handleDifficultyChange('Easy')} className={filters.difficulty === 'Easy' ? 'active' : ''}>Легкая</button>
        <button onClick={() => handleDifficultyChange('Medium')} className={filters.difficulty === 'Medium' ? 'active' : ''}>Средняя</button>
        <button onClick={() => handleDifficultyChange('Hard')} className={filters.difficulty === 'Hard' ? 'active' : ''}>Сложная</button>
      </div>
    </div>
  );
};

export default FilterSidebar;
