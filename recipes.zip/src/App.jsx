// App.jsx
import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import CardContainer from './components/CardContainer';
import FilterSidebar from './components/FilterSidebar';
import RecipeModal from './components/RecipeModal';
import './App.css';

const App = () => {
  const [recipes, setRecipes] = useState([]);
  const [filteredRecipes, setFilteredRecipes] = useState([]);
  const [cuisines, setCuisines] = useState([]); // Уникальные кухни
  const [mealTypes, setMealTypes] = useState([]); // Уникальные типы блюд
  const [selectedRecipe, setSelectedRecipe] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [filters, setFilters] = useState({
    cuisine: '',
    mealType: '',
    difficulty: '',
  });

  useEffect(() => {
    const fetchRecipes = async () => {
      try {
        const response = await fetch('https://dummyjson.com/recipes');
        const data = await response.json();
        
        setRecipes(data.recipes);
        setFilteredRecipes(data.recipes);
        
        // Извлекаем уникальные кухни и типы блюд
        const uniqueCuisines = [...new Set(data.recipes.map(recipe => recipe.cuisine))];
        const uniqueMealTypes = [...new Set(data.recipes.flatMap(recipe => recipe.mealType))];
        
        setCuisines(uniqueCuisines);
        setMealTypes(uniqueMealTypes);
        
        setLoading(false);
      } catch (error) {
        setError('Ошибка при загрузке данных');
        setLoading(false);
      }
    };
    fetchRecipes();
  }, []);

  const applyFilters = (filters) => {
    setFilters(filters);
    const filtered = recipes.filter((recipe) => {
      return (
        (filters.cuisine === '' || recipe.cuisine === filters.cuisine) &&
        (filters.mealType === '' || recipe.mealType.includes(filters.mealType)) &&
        (filters.difficulty === '' || recipe.difficulty === filters.difficulty)
      );
    });
    setFilteredRecipes(filtered);
  };

  const openModal = (recipe) => {
    setSelectedRecipe(recipe);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setSelectedRecipe(null);
    setIsModalOpen(false);
  };

  return (
    <div className="app">
      <Header />
      <div className="main-content">
        <FilterSidebar
          filters={filters}
          applyFilters={applyFilters}
          cuisines={cuisines}       // Передаем уникальные кухни
          mealTypes={mealTypes}     // Передаем уникальные типы блюд
        />
        {loading ? (
          <p>Загрузка рецептов...</p>
        ) : error ? (
          <p>{error}</p>
        ) : (
          <CardContainer recipes={filteredRecipes} openModal={openModal} />
        )}
      </div>
      {isModalOpen && selectedRecipe && (
        <RecipeModal recipe={selectedRecipe} onClose={closeModal} />
      )}
    </div>
  );
};

export default App;
