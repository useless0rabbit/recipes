import { configureStore } from '@reduxjs/toolkit';
import recipesReducer from './slices/recipesSlice';
import filtersReducer from './slices/filtersSlice';
import modalReducer from './slices/modalSlice';

const store = configureStore({
  reducer: {
    recipes: recipesReducer,
    filters: filtersReducer,
    modal: modalReducer,
  },
});

export default store;
