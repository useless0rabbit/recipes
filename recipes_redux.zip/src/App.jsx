import React, { useEffect } from 'react';
import Header from './components/Header';
import CardContainer from './components/CardContainer';
import FilterSidebar from './components/FilterSidebar';
import RecipeModal from './components/RecipeModal';
import './App.css';
import { useDispatch, useSelector } from 'react-redux';
import { fetchRecipes, applyFilters } from './redux/slices/recipesSlice';

const App = () => {
  const dispatch = useDispatch();

  const { filteredRecipes, loading, error, cuisines, mealTypes } = useSelector((state) => state.recipes);
  const filters = useSelector((state) => state.filters);

  useEffect(() => {
    dispatch(fetchRecipes());
  }, [dispatch]);

  useEffect(() => {
    dispatch(applyFilters(filters));
  }, [filters, dispatch]);

  return (
    <div className="app">
      <Header />
      <div className="main-content">
        <FilterSidebar cuisines={cuisines} mealTypes={mealTypes} />
        {loading ? (
          <p>Загрузка рецептов...</p>
        ) : error ? (
          <p>{error}</p>
        ) : (
          <CardContainer recipes={filteredRecipes} />
        )}
      </div>
      <RecipeModal />
    </div>
  );
};

export default App;
